export interface Product {
  id: string
  name: string
  description: string
  price: number
  product_url: string
  store_url: string
  category: string
  images: string[]
}

export interface CartItem extends Product {
  quantity: number
}

